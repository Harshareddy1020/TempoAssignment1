Step1: install dependencies

npm install

Step2: start the app.

npm start